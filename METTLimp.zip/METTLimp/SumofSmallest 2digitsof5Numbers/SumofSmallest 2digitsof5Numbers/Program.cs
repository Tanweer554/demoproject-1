﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SumofSmallest_2digitsof5Numbers
{
    class Program
    {
        static void Main(string[] args)
        {
            int sum = 0;
            string s1 = input1.ToString();
            char[] c1 = s1.ToCharArray();
            Array.Sort(c1);
            string s2 = c1[0].ToString() + c1[1].ToString();
            int a = int.Parse(s2);

            string s3 = input2.ToString();
            char[] c2 = s3.ToCharArray();
            Array.Sort(c2);
            string s4 = c2[0].ToString() + c2[1].ToString();
            int b = int.Parse(s4);

            string s5 = input3.ToString();
            char[] c3 = s5.ToCharArray();
            Array.Sort(c3);
            string s6 = c3[0].ToString() + c3[1].ToString();
            int c = int.Parse(s6);

            string s7 = input4.ToString();
            char[] c4 = s7.ToCharArray();
            Array.Sort(c4);
            string s8 = c4[0].ToString() + c4[1].ToString();
            int d = int.Parse(s8);

            string s9 = input5.ToString();
            char[] c5 = s9.ToCharArray();
            Array.Sort(c5);
            string s10 = c5[0].ToString() + c5[1].ToString();
            int e = int.Parse(s10);

            sum = a + b + c + d + e;
            return sum;
        }
    }
}
