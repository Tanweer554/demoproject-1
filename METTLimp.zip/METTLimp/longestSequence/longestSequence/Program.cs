﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace longestSequence
{
    class Program
    {
        static void Main(string[] args)
        {
            int no_of_sequence = 0;
            int long_sequence = 0;
            int count = 1;

            for (int i = 1; i < input1.Length; i++)
            {
                if (input1[i - 1] > input1[i])
                {
                    count = count + 1;
                }
                else
                {
                    if (count > 1)
                    {
                        no_of_sequence = no_of_sequence + 1;

                        if (count > long_sequence)
                        {
                            long_sequence = count;
                        }
                        count = 1;
                    }
                }

            }
            if (count > 1)
            {
                no_of_sequence = no_of_sequence + 1;

                if (count > long_sequence)
                {
                    long_sequence = count;
                }
                count = 1;
            }
            Result res = new Result();
            res.output1 = no_of_sequence;
            res.output2 = long_sequence;
            return res;
        }
    }
}
