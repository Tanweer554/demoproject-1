﻿using System;

namespace VoterEntry
{
    public class Voter
    {
       // TODO: Write your code Here
    }
}
