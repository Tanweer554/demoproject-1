﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VoterEntry.Utility
{
    public class VoterUtility
    {
        public string GenerateVoterID(string strFirstName, string strLastName, DateTime dtDateofBirth)
        {
            throw new NotImplementedException();

        }       
    }
}
