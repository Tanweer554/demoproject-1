﻿using System;
using System.Collections.Generic;
namespace VoterEntry
{
    public class VoterManagement
    {
       // TODO: Write your code here

        public VoterManagement()
        {
            throw new NotImplementedException();
        }

        public string AddVoter(Voter obj)
        {
            throw new NotImplementedException();
        }

        public bool ModifyVoter(Voter obj)
        {
            throw new NotImplementedException();
        }

        public Voter SearchVoter(string strVoterID)
        {
            throw new NotImplementedException();
        }

        public bool DeleteVoter(string strVoterID)
        {
            throw new NotImplementedException();
        }

        public List<Voter> GetVoterList()
        {
            throw new NotImplementedException();
        }
    }
}
