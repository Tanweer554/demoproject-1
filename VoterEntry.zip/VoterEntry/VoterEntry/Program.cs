﻿using System;

namespace VoterEntry
{
    class Program
    {
        static void Main(string[] args)
        {          
        }
    }
}
