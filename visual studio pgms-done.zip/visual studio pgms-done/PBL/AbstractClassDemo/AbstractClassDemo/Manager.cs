﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractClassDemo
{
    abstract class Manager
    {
        string EmpName;       
        public Manager()
        {
            Console.WriteLine("Manager constructor is called");
        }

        public Manager(string EmpName)
        {
            this.EmpName = EmpName;
        }

        public void ManageTeam()
        {
            Console.WriteLine("Managing the team");
        }

        public abstract void Work();

        public void Display()
        {
            Console.WriteLine("Name:"+EmpName);
        }

    }

    class HRManager : Manager
    {
        public HRManager():base("Smith")
        {
            Console.WriteLine("HR Manager constructor is called");
        }
        public override void Work()
        {
            Console.WriteLine("HR Manger is working");
        }
    }

    class TechManager : Manager
    {
        public override void Work()
        {
            Console.WriteLine("Tech Manager is working");
        }
    }
}
