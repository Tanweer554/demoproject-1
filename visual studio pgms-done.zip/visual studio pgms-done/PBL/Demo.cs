namespace MyConsoleApp
{
class Demo
{
	public static void Main()
	{
		System.Console.WriteLine("Welcome to C#");
	}	
}
}	