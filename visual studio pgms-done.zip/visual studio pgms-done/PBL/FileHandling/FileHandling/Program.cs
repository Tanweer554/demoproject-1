﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileHandling
{
    class Program
    {
        static void Main(string[] args)
        {
            //File.Create("Demo.txt");
            //File.WriteAllLines("Demo.txt",new string[] { "Welcome to File IO", "New line" });
            string str=File.ReadAllText("Demo.txt");
            
            Console.WriteLine(str);
            Console.WriteLine(File.Exists("Demo.txt"));

            File.Encrypt("Demo.txt");
            Console.WriteLine(File.GetCreationTime("Demo.txt"));            
        }
    }
}
