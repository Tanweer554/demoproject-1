﻿using System;

namespace ApplicationExceptions
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Employee obj = new Employee()
                {
                    EmployeeID = 100,
                    EmployeeName = "SMith",
                    Age = 10
                };
            }
            catch (AgeException exp)
            {
                Console.WriteLine(exp.Message);
            }
            
        }
    }
}
