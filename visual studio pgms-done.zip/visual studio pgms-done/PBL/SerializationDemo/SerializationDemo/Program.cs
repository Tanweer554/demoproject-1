﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace SerializationDemo
{
    class Program
    {
        
        static void Main(string[] args)
        {
            Employee obj = new Employee() {
                EmployeeID=1000,
                EmployeeName="Smith"
            };

            BinaryFormatter objFormatter = new BinaryFormatter();
            FileStream objStream = new FileStream("EmpData.txt", FileMode.Create);
            objFormatter.Serialize(objStream, obj);
            objStream.Close();
            Console.WriteLine("Object serialized...");

            Employee empData=(Employee)objFormatter.Deserialize(new FileStream("EmpData.txt", FileMode.Open));
            Console.WriteLine(empData.EmployeeID);
            Console.WriteLine(empData.EmployeeName);
        }
    }

    [Serializable]
    class Employee
    {
        [NonSerialized]
        public int EmployeeID;
        public string EmployeeName { get; set; }
    }
}
