﻿using System;
#nullable enable;
using System.Collections.Generic;

//Read only region start

namespace IntegralOccurences
{
    
    public class UserMainCode
    {
        static void Main(string[] args)
        {
            Console.WriteLine(new UserMainCode().MostFrequentDigit(123, 456, 345, 5043));
        }
        public int MostFrequentDigit(int input1, int input2, int input3, int input4)
        {
            //Read only region end
            //Write code here
            SortedList<int,int> objRecurrences = new SortedList<int, int>();
            string str = input1.ToString() + input2.ToString() + input3.ToString() + input4.ToString();
            for (int j = 0; j < str.Length; j++)
            {
                char ch = str[j];
                int count = 0;
                for (int i = 0; i < input1.ToString().Length; i++)
                {
                    if (input1.ToString()[i] == ch)
                    {
                        count++;
                    }
                }

                for (int i = 0; i < input2.ToString().Length; i++)
                {
                    if (input2.ToString()[i] == ch)
                    {
                        count++;
                    }
                }

                for (int i = 0; i < input3.ToString().Length; i++)
                {
                    if (input3.ToString()[i] == ch)
                    {
                        count++;
                    }
                }

                for (int i = 0; i < input4.ToString().Length; i++)
                {
                    if (input4.ToString()[i] == ch)
                    {
                        count++;
                    }
                }
                int value = 0;
                if (int.TryParse(((char)ch).ToString(), out value))
                {
                    objRecurrences.Add(value, count);
                }
                
                str = str.Replace(ch, ' ');
            }
                     
            
            int[] values = new int[objRecurrences.Values.Count];
            objRecurrences.Values.CopyTo(values, 0);
            Array.Sort(values);
            int maxValue = values[values.Length - 1];
            int[] keyValues = new int[objRecurrences.Count];
            int k = 0;
            foreach (KeyValuePair<int, int> item in objRecurrences)
            {
                if (item.Value == maxValue)
                {
                    keyValues[k] = item.Key;
                    k++;
                }
            }
            Array.Sort(keyValues);
            return (keyValues[keyValues.Length-1]) ;
        }
    }
}