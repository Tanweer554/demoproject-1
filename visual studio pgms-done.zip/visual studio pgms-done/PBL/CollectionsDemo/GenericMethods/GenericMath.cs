﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericMethods
{
    class GenericMath<T>
    {
        public T Add(T a, T b)
        {
            dynamic firstValue = a;
            dynamic secondValue = b;
            dynamic result = firstValue + secondValue;
            return result;
        }

        public dynamic DynamicAdd(dynamic a, dynamic b)
        {
            return (a + b);
        }
    }
}
