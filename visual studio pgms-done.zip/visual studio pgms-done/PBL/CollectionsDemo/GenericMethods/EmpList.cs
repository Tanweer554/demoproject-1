﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericMethods
{
    class EmpList
    {
        static void Main(string[] args)
        {
            List<int> objIntList = new List<int>();
            for(int i=0;i<10;i++)
                objIntList.Add(i);

            for (int i = 0; i < 10; i++)
                objIntList[i] = objIntList[i] * 2;

            foreach(var item in objIntList)
                Console.WriteLine(item);
            

            
        }
    }
}
