﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EarlyBindingDemo
{
    class CustomMath
    {
        public int Add(int a, int b)
        {
            return (a + b);
        }

        public int Add(int[] a)
        {
            int sum = 0;
            foreach (var i in a)
            {
                sum += i;
            }

            return sum;
        }

        public string Add(string str1, string str2)
        {
            return (str1 + str2);
        }
    }
}
