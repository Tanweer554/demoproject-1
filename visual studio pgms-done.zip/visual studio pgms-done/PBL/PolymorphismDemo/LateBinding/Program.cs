﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LateBinding
{
    class Program
    {
        static void Main(string[] args)
        {
            Base objBase = new Base(); // Base ref is poining to Base obj.
            objBase.Display(); // From Base

            Derived objDerived = new Derived();
            objDerived.Display(); // From Derived

            objBase = new Derived(); // Base ref is pointing to Derived obj.
            objBase.Display(); // From Derived
            
        }
    }
}
