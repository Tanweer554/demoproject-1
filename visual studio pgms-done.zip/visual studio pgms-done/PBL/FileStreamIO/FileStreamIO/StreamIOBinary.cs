﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileStreamIO
{
    class StreamIOBinary
    {
        static void Main(string[] args)
        {
            FileStream objStream = new FileStream("Demo.txt", FileMode.Create);
            BinaryWriter objWriter = new BinaryWriter(objStream);
            objWriter.Write("Welcome to Stream based IO operations");
            objWriter.Close();
            objStream.Close();
            Console.WriteLine("File created successfully...");

            FileStream objReaderStream = new FileStream("Demo.txt", FileMode.Open);
            BinaryReader objReader = new BinaryReader(objReaderStream);
            FileInfo objInfo = new FileInfo("Demo.txt");
            Console.WriteLine(objInfo.Length);
            
            while (objReader.PeekChar() != -1)
            {
                Console.Write(objReader.ReadString());
            }
            objReader.Close();
            objReaderStream.Close();
        }
    }
}
