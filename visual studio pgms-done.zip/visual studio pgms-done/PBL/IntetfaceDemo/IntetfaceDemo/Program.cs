﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IntetfaceDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            //CustomMath obj = new CustomMath();
            //obj.Add(10, 20);
            //obj.Subtract(10, 20);

            //IMath obj1;
            //obj1 = new CustomMath();

            //obj1.Add(10, 100);
            //obj1.Subtract(20, 300);

            Demo obj = new Demo();
            Console.WriteLine("Using Class ref");
            obj.Display1();
            obj.Display2();

            Console.WriteLine("Using Interface Ref.");
            FirstInterface objFirst = new Demo();
            SecondInterface objSecond = new Demo();

            objFirst.Display1();
            objSecond.Display2();
        }
    }
}
