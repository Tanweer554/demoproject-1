﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classExmpl
{
    class Emp : Persn
    {
        public Emp(string nm, int id, int sal)
        {
            Empnm = nm;
            Empid = id;
            Salary = sal;

        }


    }
}
