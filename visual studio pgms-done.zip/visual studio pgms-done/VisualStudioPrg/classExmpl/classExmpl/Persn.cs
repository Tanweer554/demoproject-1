﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classExmpl
{
    class Persn
    {
     public   string Empnm;
     public   int Empid;
      public  int Salary;
        //int x, y;

        public Persn()
        {

        }

        public Persn( string nm, int id, int sal)
        {
            //Empnm = nm;
            //Empid = id;
            //Salary = sal;
            //x = id;
            //y = sal;

           // Console.WriteLine("The adition is : "+(x+y));

        }

        public void Show()
        {
            Console.WriteLine("Emp Name : {0}", Empnm);
            Console.WriteLine("Emp Id : {0}", Empid);
            Console.WriteLine("Emp Salary : {0}", Salary);
        }



    }
}
