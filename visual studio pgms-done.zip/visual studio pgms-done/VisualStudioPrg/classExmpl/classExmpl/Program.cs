﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classExmpl
{
    class Program
    {
        static void Main()
        {
            DateTime dt = DateTime.Now;
            int day = dt.Day;
            int month = dt.Month;
            int year = dt.Year;

            Console.WriteLine(day);
            Console.WriteLine(month);
            Console.WriteLine(year);

            //Console.WriteLine(dt);
            //Console.WriteLine(dt.Date);
            //Console.WriteLine(dt.Date.ToShortDateString());
            //Console.WriteLine(dt.Day);
            //Console.WriteLine(dt.DayOfWeek);
            //Console.WriteLine(dt.Month);
            //Console.WriteLine(dt.Year);

            string inp_dt;

            inp_dt = Console.ReadLine();

            DateTime x = DateTime.Parse(inp_dt);

            Console.WriteLine(x.Date.ToShortDateString());

        }
    }
}
