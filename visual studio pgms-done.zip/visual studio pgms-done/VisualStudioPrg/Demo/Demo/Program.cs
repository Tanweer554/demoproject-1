﻿using System;

namespace Demo
{
    class Program
    {
        static void Main(string[] args)
        {
            //double a, b ;
            //double c;
            string str;
            //Console.Write("Enter the 1st number :");
            //a = Convert.ToInt32(Console.ReadLine());
            //Console.WriteLine();
            //Console.Write("Enter the 2nd number :");
            //b = Convert.ToInt32(Console.ReadLine());
            //Console.WriteLine();
            ////c = a / b;

            //if(a>b)
            //{
            //    Console.WriteLine("The value of {0} is greater than {1}",a,b);
            //}
            //else
            //{
            //    Console.WriteLine("The value of {0} is greater than {1}",b,a);
            //}

            str = "Hello 123";
            int n=0;
            int m = 0;

            foreach (char st in str)
            {
                bool s = char.IsDigit(st);
                if (s)
                {
                    n++;
                    Console.WriteLine("Numbers :");
                    Console.WriteLine(st);
                }
                else
                {
                    m++;
                    Console.WriteLine("Alphabets :");
                    Console.WriteLine(st);
                }
                
            }

            Console.WriteLine("No. of Characters are : {0}, and Numbers are : {1}", m,n);

            //"ABCD" -> "DCBA - BCD - C - AB$D" STR1=ABCD; STR2=AB$D  


            //Console.WriteLine("The value of c is {0} ", c);


            //Console.WriteLine("Hello World");
 

        }
    }
}
