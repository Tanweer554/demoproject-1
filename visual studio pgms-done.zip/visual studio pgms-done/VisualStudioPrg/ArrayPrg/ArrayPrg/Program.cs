﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArrayPrg
{
    class Program
    {
        static void Main(string[] args)
        {
            char[] letters = { 'H', 'e', 'l', 'l', 'o' };
            string[] sarray = { "Hello", "From", "Tutorials", "Point" };
            int[] intarr = new int[10]; // Method 1
            int[] intar2 = { 12, 23, 21, 14, 41, 31, 10, 8, 34, 56 }; // Method 2
            int[,] Arr1 = new int[4, 3];


            int[,] Arr2 = { {3,2,6 }, { 4,5,8}, { 5, 6,9 }, { 7, 8,2 } };




            //Reading emelents from Array

            foreach(char c in letters)
            {
                Console.Write(c+" ");
            }

            Console.WriteLine();

            foreach(string s in sarray)
            {
                Console.Write(s +" ");
            }
            Console.WriteLine();

            intarr[0] = 2;
            intarr[1] = 22;
            intarr[2] = 32;
            intarr[3] = 12;
            intarr[4] = 82;
            intarr[5] = 72;
            intarr[6] = 62;
            intarr[7] = 52;
            intarr[8] = 42;
            intarr[9] = 32;
            //intarr[10] = 100;

            foreach(int i in intarr)
            {
                Console.Write(i +" ");
            }
            Console.WriteLine();

            int l = intarr.Length;

            Console.WriteLine(l);

            for ( int x =0; x<l;x++)
            {
                Console.Write(intarr[x]+" ");
            }
            Console.WriteLine();

            // Reading from the Array intar2

            Console.WriteLine();
            foreach (int i1 in intar2)
            {
                Console.Write(i1 + " ");
            }
            Console.WriteLine();

            int l1 = intar2.Length;

            Console.WriteLine(l1);

            for (int x = 0; x < l1; x++)
            {
                Console.Write(intar2[x] + " ");
            }
            Console.WriteLine();

            Array.Sort(intar2);

            Console.WriteLine();

            Console.WriteLine("The sorted array :");

            foreach (int i1 in intar2)
            {
                Console.Write(i1 + " ");
            }
            Console.WriteLine();

            Array.Reverse(intar2);
            Console.WriteLine("Array in descending order : ");
            Console.WriteLine();
            foreach (int i1 in intar2)
            {
                Console.Write(i1 + " ");
            }
            Console.WriteLine();
        }
    }
}
