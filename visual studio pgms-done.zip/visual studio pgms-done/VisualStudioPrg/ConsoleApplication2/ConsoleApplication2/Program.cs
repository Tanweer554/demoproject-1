﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
   
    class Program
    {
        static void Main()
        {
            Student st = new Student( 1234, 2017, "John");
            //st.stNm = "John";
            //st.RollNo = 1234;
            //st.Year = 2017;

            st.Print();

        }
    }
}
