﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    class Student
    {
        private string stNm = "Sugar";
        private int RollNo=456;
        private int Year=2019;


        public Student( int roll,int yr, string nm)
        {
            stNm = nm;
            RollNo = roll;
            Year = yr;

        }



       public void Print()
        {
            Console.WriteLine("The student name is : {0}",stNm);
            Console.WriteLine("The student RollNo is : {0}", RollNo);
            Console.WriteLine("The student Year is : {0}", Year);
        }


    }
}
