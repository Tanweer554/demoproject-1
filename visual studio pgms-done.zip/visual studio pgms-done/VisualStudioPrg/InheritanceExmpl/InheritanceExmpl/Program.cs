﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceExmpl
{
    class Program
    {
        static void Main(string[] args)
        {
            //Employee emp = new Employee("Amit",554293);

            //emp.Disp();

            string str = "bangalore";

            char[] c = str.ToCharArray();
            Console.WriteLine(str.Substring(1));
            Console.WriteLine(str.Substring(1,3));

            Array.Reverse(c);

            foreach(char x in c)
            {
                Console.WriteLine(x);
            }

            string str1 = new string(c);

            Console.WriteLine(str1);

        }
    }
}
