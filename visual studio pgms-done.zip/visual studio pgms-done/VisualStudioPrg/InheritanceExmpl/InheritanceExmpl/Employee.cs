﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceExmpl
{
    class Employee:Person
    {
        public Employee(string nm,int id)
        {
            EmpNm = nm;
            EmpId = id;
        }
        public void Disp()
        {
            Console.WriteLine("Employee name : {0}",EmpNm);
            Console.WriteLine("Employee id : {0}", EmpId);
        }
    }
}
