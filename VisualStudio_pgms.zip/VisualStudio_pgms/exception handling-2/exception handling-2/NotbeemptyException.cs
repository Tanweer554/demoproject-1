﻿using System;
using System.Runtime.Serialization;

namespace exception_handling_2
{
    class NotbeemptyException : Exception
    {
        public NotbeemptyException(string message) : base(message)
        {

        }
    }
}