﻿using System;
using System.Runtime.Serialization;

namespace exception_handling_2
{
    class NotDigitsException:Exception
    {
        public NotDigitsException(string message):base(message)
        {

        }
    }
   
}