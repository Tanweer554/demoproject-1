﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exception_handling_2
{
    class person
    {
        string s;
        string r;

        public void display()
        {
            try
            {
                Console.WriteLine("First name is:");
                s = Console.ReadLine();
               
               if (string.IsNullOrEmpty(s))
                {
                    throw new NotbeemptyException("Please enter the first name");
                }
               foreach(char c in s)
                {
                    if (!Char.IsLetter(c))
                    {
                        throw new NotDigitsException("Numbers are not allowed");
                    }
                }
                Console.WriteLine("last name is:");
                r = Console.ReadLine();

                if (string.IsNullOrEmpty(r))
                {
                    throw new NotbeemptyException("Please enter the last name");
                }
            }
            catch (NotbeemptyException nex)
            {
                Console.WriteLine(nex.Message);
            }
            catch(NotDigitsException nod)
            {
                Console.WriteLine(nod.Message);
            }
        }
    

    }
}
