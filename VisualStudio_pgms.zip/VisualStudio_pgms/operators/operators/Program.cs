﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace operators
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter num1 value");
            int n1=Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter num2 value");
            int n2 = Convert.ToInt32(Console.ReadLine());
            int temp = n1;
            n1 = n2;
            n2 = temp;
            Console.WriteLine("after swapping numbers are {0},{1}", n1, n2);
            Console.ReadKey();
            n2 = ++n1;
            Console.WriteLine("n2 value after pre-incrementing is {0}",n2);
            Console.ReadKey();
            n2 = n1++;
            Console.WriteLine("n2 value after post-incrementing is {0}", n2);
            Console.ReadKey();
           


        }
    }
}
