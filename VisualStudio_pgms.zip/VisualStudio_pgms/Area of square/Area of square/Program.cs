﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Area_of_square
{
    class Program
    {
        static void Main(string[] args)
        {
            double side, area;
            Console.WriteLine("Enter the length of the side");
            side = Convert.ToDouble(Console.ReadLine());
            area = side * side;
            Console.WriteLine("Area of the square is: " + area);
            Console.ReadKey();
        }
    }
}
