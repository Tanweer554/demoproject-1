﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace format_exception
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                int[,] marks = new int[3, 3];
                string[] name = new string[3];
                for (int i = 0; i < 3; i++)
                {
                    Console.WriteLine("Enter the name of the student:");
                    name[i] = Console.ReadLine();
                    for (int j = 0; j < 3; j++)
                    {
                        Console.WriteLine("Marks for subject {0}", j);
                        int a = Convert.ToInt32(Console.ReadLine());
                        try
                        {
                            if (a < 0)
                            {
                                throw new NegativeNumberException("Marks can't be negative !!!!");
                            }
                            else
                            {
                                marks[i, j] = a;
                            }
                        }
                        catch(Exception e)
                        {
                            j--;
                            Console.WriteLine("{0}",e.Message);
                        }
                    }
                }
            }
            catch (FormatException)
            {
                Console.WriteLine("Enter Only Integers !!!!!!!");
            }
        }
    }

    internal class NegativeNumberException : Exception
    {
     
        public NegativeNumberException(string message) : base(message)
        {
        }

       
        
    }
}