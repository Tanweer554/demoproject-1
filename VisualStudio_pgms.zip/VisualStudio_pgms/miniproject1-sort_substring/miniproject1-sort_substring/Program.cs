﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace miniproject1_sort_substring
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the no of inputs to be given");
            int x = Convert.ToInt32(Console.ReadLine());
         
            string[] str = new string[x];
            Console.WriteLine("Enter the string and N and M values with space");
            for (int i = 0; i < x; i++)
            {
                str[i] = Console.ReadLine();
            }
            for(int i = 0; i < x; i++)
            {
                string[] str1 = str[i].Split(' ');
                int a = Convert.ToInt32(str1[1]);
                int b = Convert.ToInt32(str1[2]);
                string str2 = str1[0].Substring(a, b);
                char[] c = str2.ToCharArray();
                Array.Sort(c);
                Array.Reverse(c);
                string res2 = " ";
                foreach(char s in c)
                {
                    res2 = res2 + s;
                }
                string res1 = str1[0].Substring(0, a);
                string res3 = str1[0].Substring(b + a);
                string final = res1 + res2 + res3;
                Console.WriteLine("the ouput is:{0}",final);


            }
            Console.ReadKey();
        }
    }
}
