﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace details_of_car
{
    class Program
    {
        
        static void Main(string[] args)
        {
            car cr = new car("honda", "M3e5", 1997, 78000);
            car cr2 = new car("lamborgini", "vice234", 2003, 500000);
            cr.displaycar();
            cr2.displaycar();

        }
    }
}
