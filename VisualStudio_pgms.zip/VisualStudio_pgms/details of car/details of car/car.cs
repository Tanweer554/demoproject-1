﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace details_of_car
{
    class car
    {
        private string carmake;
        private string model;
        private int mfgyear;
        private int price;
        public car(string manufacturer,string type,int mfyear,int cost)
        {
            carmake = manufacturer;
            model = type;
            mfgyear = mfyear;
            price = cost;
        }
        public void displaycar()
        {
            Console.WriteLine("carmaker:{0}\t year_of_making:{1}\t model:{2}\t price:{3}",carmake,model,mfgyear,price);
        }
    }
}
