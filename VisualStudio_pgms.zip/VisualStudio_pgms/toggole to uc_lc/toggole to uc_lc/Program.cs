﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace toggole_to_uc_lc
{
    class Program
    {
        static void Main(string[] args)
        {
            string str;
            Console.WriteLine("Enter the string");
            str=Console.ReadLine();
            foreach(char st in str)
            {
                string cstr=Convert.ToString(st);
                Console.Write("" + cstr.ToLower());
            }
            Console.ReadKey();
        }

    }
}
