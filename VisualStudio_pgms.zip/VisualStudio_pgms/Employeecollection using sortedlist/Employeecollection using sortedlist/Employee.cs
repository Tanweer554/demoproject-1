﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employeecollection_using_sortedlist
{
    class Employee
    {
        public string Employeename { get; set; }
        public int Employeeid { get; set; }
        public double salary { get; set; }
    }
}
