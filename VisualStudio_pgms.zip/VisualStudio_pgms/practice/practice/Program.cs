﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace practice
{
    class Program
    {
        
     

        static void Main(string[] args)
        {
            
            Char[] c = new char[10];
            int rem=0;
            Console.WriteLine("Enter the input");
            int a=int.Parse(Console.ReadLine());
            int b = Math.Abs(a);
            Console.WriteLine("b is:{0}",b);
            // int c = b;
           
            while (b > 0)
            {
                rem = b % 10;
                b = b / 10;


                if (rem % 2 == 0)
                {
                   
                    Console.WriteLine("e");
                }
                else if(rem%2!=0)
                {
                    Console.WriteLine("o");
                }

            }
            if (a < 0)
            {
                Console.WriteLine("n");
            }
            else
            {
                Console.WriteLine("p");
            }

        }


    }
}
