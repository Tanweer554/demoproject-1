﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employeecollection_using_generic_list
{
    class Employee
    {
    }
}
