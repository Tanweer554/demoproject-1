﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace inc_str_by1
{
    class Program
    {
        static void Main(string[] args)
        {
            string str;
            Console.WriteLine("Enter the string");
            str=Console.ReadLine();
            foreach(int st in str)
            {
                //int number = Convert.ToInt32(st);
                Console.WriteLine(""+Convert.ToChar(st+ 1));
              
            }
            Console.ReadKey();
        }
    }
}
