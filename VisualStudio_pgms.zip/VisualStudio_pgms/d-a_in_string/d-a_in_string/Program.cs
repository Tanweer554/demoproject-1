﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace d_a_in_string
{
    class Program
    {
        static void Main(string[] args)
        {
            string str;
            int m = 0, n = 0;
            Console.WriteLine("Enter the string");
            str = Console.ReadLine();
            foreach(char st in str)
            {
                bool s = char.IsDigit(st);
                if (s)
                {
                    m++;
                    Console.WriteLine("Numbers:");
                    Console.WriteLine(st);
                }
                bool t = char.IsLetter(st);
                if (t)
                {
                    n++;
                    Console.WriteLine("Characters:");
                    Console.WriteLine(st);

                }
            }
            Console.WriteLine("Numbers of digits are {0} and alphabets are {1}", m, n);
            Console.ReadKey();
        }
    }
}
