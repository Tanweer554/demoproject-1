﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(nthFibonacci(5));
        }


        public static long nthFibonacci(int input1)
        {
            //Read only region end
            //Write code here
            /*     int a=0;
                 int b=1;
                 int c;
                 for(int i=0;i<input1;i++){
                  c=a+b;
                     a=b;
                     b=c;
                 }return c;*/
            long result = 0;

            int first = 0;
            int second = first + 1;
            int last;
            int i = input1;
            int[] a = new int[input1];
            int j = 0;
            a[j] = first;
            j++;
            if (j < input1) a[j] = second;

            j++;
            for (i = 0; i < input1; i++)
            {
                last = first + second;
                if (j < input1)
                    a[j] = last;
                first = second;
                second = last;
                j++;
            }

            for (i = 0; i < a.Length; i++)
            {
                Console.WriteLine(a[i]);
            }
            return a[input1 - 1];

        }
    }
}
