﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace employee_properties_using_inheritance
{
    class Houlyemployee : person,Ipayable
    {
        public Double Hoursworked;
        public Double payperhour;
        public Houlyemployee(double Hoursworked, double payperhour, string firstname, string lastname, string emailid, DateTime dob) : base(firstname, lastname, emailid, dob)
        {
            this.Hoursworked = Hoursworked;
            this.payperhour = payperhour;
        }
        public double calculate()
        {
            double pay = Hoursworked * payperhour;
            return pay;
        }
    }
}
