﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace employee_properties_using_inheritance
{
    class person
    {
        public string firstname;
        public string lastname;
        public string emailid;
        public DateTime dob;
        DateTime dt = DateTime.Now;

        public person( string firstname,string lastname,string emailid,DateTime dob)
        {
            this.firstname = firstname;
            this.lastname = lastname;
            this.emailid = emailid;
            this.dob = dob;
        }
        public bool IsAdult()
        {
            int a = dt.Year;
            int b = dob.Year;
            if ((a - b) > 18)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public string SunSign()
        {
            switch (dob.Month)
            {
                case 1:
                    if (dob.Day <= 20)
                    { return "capricon";  }
                    else
                    { return "Aquarius"; }
                 
           
                case 2:
                    if (dob.Day <= 19)
                    { return "Aquarius"; }
                    else
                    { return "pisces"; }
                    
                case 3:
                    if (dob.Day <= 20)
                    { return "pisces"; }
                    else
                    { return "Aries"; }
                   
                case 4:
                    if (dob.Day <= 20)
                    { return "Aries"; }
                    else
                    { return "Taurus"; }
                  
                case 5:
                    if (dob.Day <= 21)
                    { return "Taurus"; }
                    else
                    { return "Gemini"; }
                  
                case 6:
                    if (dob.Day <= 22)
                    { return "Gemini"; }
                    else
                    { return "Cancer"; }
                    
                case 7:
                    if (dob.Day <= 22)
                    { return "Cancer"; }
                    else
                    { return "Leo"; }
                   
                case 8:
                    if (dob.Day <= 23)
                    { return "Leo"; }
                    else
                    { return "Virgo"; }
                   
                case 9:
                    if (dob.Day <= 23)
                    { return "Virgo"; }
                    else
                    { return "Libra"; }
                   
                case 10:
                    if (dob.Day <= 23)
                    { return "Libra"; }
                    else
                    { return "Scorpio"; }
                   
                case 11:
                    if (dob.Day <= 22)
                    { return "Scorpio"; }
                    else
                    { return "Sagittarius"; }
                    
                case 12:
                    if (dob.Day <= 21)
                    { return "sagittarius"; }
                    else
                    { return "Capricon"; }
                    
                default:
                    return "Sign Not Found";
                   
            }
        }
        public bool IsBirthday()
        {
            int x = dt.Day;
            int y = dt.Month;
            int z = dob.Day;
            int w = dob.Month;
            if((x==z)&& (y == w))
            {
                return true;
            }
            else
            {
                return false;
            }

        }
        public string ScreenName()
        {
            string str = firstname + dob.Month + dob.Day + lastname;
            return str;
        }
    }
}
