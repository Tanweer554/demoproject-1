﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace employee_properties_using_inheritance
{
    class employee: person
    {
        public double Salary;

        public employee(double salary,string firstname, string lastname, string emailid, DateTime dob) : base(firstname, lastname, emailid, dob)
        {
            this.Salary = salary;
        }
    }
}
