﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace employee_properties_using_inheritance
{
    class Permenantemployee : employee,Ipayable
    {
        public double HRA;
        public double DA;
        public double Tax;
        public double Netpay;
        public double Totalpay;

        public Permenantemployee(double HRA,double DA,double Tax,double Netpay,double Totalpay,double salary, string firstname, string lastname, string emailid, DateTime dob) : base(salary, firstname, lastname, emailid, dob)
        {
            this.HRA = HRA;
            this.DA = DA;
            this.Tax = Tax;
            this.Netpay = Netpay;
            this.Totalpay = Totalpay;
        }
        public double calculate()
        {
            HRA = Salary * 0.15;
            DA = Salary * 0.1;
            Tax = Salary * 0.08;
            Totalpay = HRA + DA;
            Netpay = Totalpay - Tax;
            return Netpay;
        }
    }
}
