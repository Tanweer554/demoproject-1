﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace employee_properties_using_inheritance
{
      interface Ipayable
    {
        double calculate();
    }
    class Program
    {
        static void Main(string[] args)
        {
            employee p = new employee(25000, "Tanweer", "Ahmed", "tanweer554@gmail.com", new DateTime(1997, 04, 23));
            bool q = p.IsAdult();
            if (q == true)
            {
                Console.WriteLine("*********** Adult **************");
            }
            else
            {
                Console.WriteLine("********** Child *******************");
            }
            string s = p.SunSign();
            Console.WriteLine("sun sign is : {0}",s);
            bool w = p.IsBirthday();
            if (w == true)
            {
                Console.WriteLine("Today is birthday");
            }
            else
            {
                Console.WriteLine("Birthday is not today");
            }
            string str1 = p.ScreenName();
            Console.WriteLine("screen name is {0}",str1);
            Console.WriteLine("person salary is{0}",p.Salary);

            Houlyemployee h = new Houlyemployee(9.5, 5000, "mohammed", "ahmed", "mohammed.ahmed@gmail.com", new DateTime(1998, 05, 25));
            double j = h.calculate();
            Console.WriteLine("pay of hourly employee is:{0}",j);

            Permenantemployee per =  new Permenantemployee(25000, 5000, 5000, 30000, 50000, 60000, "manu", "tanu", "tanuwedsmanu@gmail.com", new DateTime(1997, 04, 23));
            double k = per.calculate();
            Console.WriteLine("pay of permenant employee is:{0}", k);

            Console.ReadLine();
        }
       
       
    }
}
