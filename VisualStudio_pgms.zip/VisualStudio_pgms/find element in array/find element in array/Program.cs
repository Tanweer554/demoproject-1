﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace find_element_in_array
{
    class Program
    {
        static void Main(string[] args)
        {
            int count=0;
            int i;
            int[] array = { 1, 2, 3, 4, 5, 6, 7, 8, 9 ,10};
            for (i = 0; i <= array.Length - 1; i++)
            {
                count++;
            }
            Console.WriteLine("{0} elements are their in the array",count);
            Console.ReadKey();
        }
    }
}
