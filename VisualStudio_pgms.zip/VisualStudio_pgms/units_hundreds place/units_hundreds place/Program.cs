﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace units_hundreds_place
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 1;
            Console.WriteLine("enter value of n1");
            int n1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter value of n2");
            int n2 = Convert.ToInt32(Console.ReadLine());
            while (n1 > 0)
            {
                int rem = n1 % 10;
                if (rem == n2)
                {
                    break;
                }
                n1 = n1 / 10;
                i++;
            }
            switch (i)
            {
                case 1: Console.WriteLine("{0} is in units place",n2);
                        break;
                case 2:
                    Console.WriteLine("{0} is in tens place", n2);
                    break;
                case 3:
                    Console.WriteLine("{0} is in hundreds place", n2);
                    break;
                case 4:
                    Console.WriteLine("{0} is in thousands place", n2);
                    break;
            }
            Console.ReadKey();
        }
       
    }
}
