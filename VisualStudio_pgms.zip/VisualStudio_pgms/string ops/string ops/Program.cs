﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace string_ops
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter the string");
            string str = Console.ReadLine();
            string sstr = str.Substring(1);
            Console.WriteLine("Splitted substring is:");
            Console.WriteLine("{0}",sstr);
            string rstr = str.Replace('a', '$');
            Console.WriteLine("Replaced string is:");
            Console.WriteLine("{0}",rstr);
            string cstr = string.Copy(str);
            Console.WriteLine("copied string is:");
            Console.WriteLine("{0}",cstr);
            string cstring = str.Replace('e', '^');
            Console.WriteLine("string and replaced string are {0} and {1}",str,cstring);
            Console.ReadKey();
        }
    }
}
