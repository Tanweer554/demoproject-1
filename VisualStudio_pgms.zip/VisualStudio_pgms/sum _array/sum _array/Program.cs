﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace reverse_array
{
    class Program
    {
        static void Main(string[] args)
        {
            int sum = 0;
            int[] intarr1 = new int[10];
            Console.WriteLine("enter the elements of the array");
            for (int i = 0; i <= intarr1.Length - 1; i++)
            {
                intarr1[i] = Convert.ToInt32(Console.ReadLine());

            }

            for (int i = 0; i <= intarr1.Length - 1; i++)
            {
                sum += intarr1[i];
            }
            Console.WriteLine("The Sum of elements of an array is {0}", sum);
            Console.ReadKey();
        }
    }
}
