﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interest_calculator
{
    class SBaccount : IAccount
    {
        double interest_rate;
        double amount;
        public double CalculateInterest()
        {
            Console.WriteLine("Enter average amount in the account:");
            amount = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter the type of the account:\n 1. Normal \n 2. NRI");
            int type_account = int.Parse(Console.ReadLine());
            switch (type_account)
            {
                case 1:
                    interest_rate = 4;
                    double Normal_Account_Interest = (amount / 100) * interest_rate;
                    return Normal_Account_Interest;
                    break;
                case 2:
                    interest_rate = 6;
                    double NRI_Account_Interest = (amount / 100) * interest_rate;
                    return NRI_Account_Interest;
                    break;
                default:
                    return 0;
            }


        }
    }
}
