﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interest_calculator
{
    class RDaccount : IAccount
    {
        double interest_rate;
        double amount;
        public double CalculateInterest()
        {
            return 0;

        }
    }
}
