﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace interest_calculator
{
    interface IAccount
    {
        double CalculateInterest();
    }
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Select the option:\n 1.Interest Calculator-SB \n 2.Interest Calculator-FD \n 3.Interest Calculator-RD \n 4.Exit");
            int s = int.Parse(Console.ReadLine());
            switch (s)
            {
                case 1:
                    SBAccount sba = new SBAccount();
                    double sd = sba.CalculateInterest();
                    if (sd != 0)
                    {
                        Console.WriteLine("Interest is:{0}", sd);
                    }
                    else
                    {
                        Console.WriteLine("No interest");
                    }

                    break;
                case 2:
                    FDaccount fda = new FDaccount();
                    double fd = fda.CalculateInterest();
                    break;
                case 3:
                    RDaccount rda = new RDaccount();
                    double rd = rda.CalculateInterest();
                    break;
                case 4:
                    break;
            }

            Console.ReadKey();
        }
    }
}



