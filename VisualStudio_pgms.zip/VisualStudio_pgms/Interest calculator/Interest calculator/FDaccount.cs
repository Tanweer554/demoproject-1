﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interest_calculator
{
    class FDaccount : IAccount
    {
        double interest_rate;
        double amount;
        int no_of_days;
        int age;
        public double CalculateInterest()
        {
            Console.WriteLine("Enter the FD amount:");
            amount = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter the no of days:");
            no_of_days = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter your age");
            age = int.Parse(Console.ReadLine());
            if (amount > 10000000)
            {
                if (no_of_days >= 7 && no_of_days <= 14)
                {
                    if (age < 60)
                    {
                        interest_rate = 4.50;
                        double interest = (amount)
                    }
                }
            }
            return 0;
        }
    }
}
