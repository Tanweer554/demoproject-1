﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace reverse_array
{
    class Program
    {
        static void Main(string[] args)
        {
           
            int[] intarr1 = new int[10];
            Console.WriteLine("enter the elements of the array");
           for(int i=0;i<=intarr1.Length - 1; i++)
            {
                intarr1[i]=Convert.ToInt32(Console.ReadLine());

            }
            Console.WriteLine("Reverse order of array is");
           for(int i = intarr1.Length - 1; i >= 0; i--)
            {
                Console.Write("{0}\t",intarr1[i]);
            }
           
            Console.ReadKey();
        }
    }
}
