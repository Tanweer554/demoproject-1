﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace str_rev
{
    class Program
    {
        static void Main(string[] args)
        {
            string str, reverse;
            Console.WriteLine("Enter the String");
            str=Console.ReadLine();
            reverse = ReverseString(str);
            Console.ReadKey();
        }
        public static String ReverseString(String st)
        {
            char[] arr = st.ToCharArray();
            Array.Reverse(arr);
            return new string(arr);
            
        }
       
    }
}
