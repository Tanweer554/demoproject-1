﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace no_of_occurances
{
    class Program
    {
        static void Main(string[] args)
        {
            int count=0;
            Console.WriteLine("enter value of n1");
            int n1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter value of n2");
            int n2 = Convert.ToInt32(Console.ReadLine());
            while (n1 > 0)
            {
                int rem = n1 % 10;
                if (rem == n2)
                {
                    count++;
                }
                n1 = n1 / 10;
            }
            Console.WriteLine("No of occurances of {0} is {1}",n2,count);
            Console.ReadKey();
        }
    }
}
