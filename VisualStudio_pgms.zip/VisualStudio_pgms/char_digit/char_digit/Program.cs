﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace char_digit
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the charcter");
            char ch = Convert.ToChar(Console.ReadLine());
            bool b = Char.IsDigit(ch);
            if (b)
            {
                Console.WriteLine("{0} is a digit",ch);
            }
            else
            {
                Console.WriteLine("{0} is a charcter",ch);
            }
            Console.ReadKey();
        }
    }
}
