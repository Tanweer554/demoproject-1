﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gen_random_numbers
{
    class Program
    {
        static void Main(string[] args)
        {
            int rint = randomhelper.Randint(1000, 70);
            double rdouble = randomhelper.Randdouble(122222, 222222222);
            Console.WriteLine("random int number is:{0}",rint);
            Console.WriteLine("random double number is:{0}",rdouble);
            Console.ReadKey();
        }
    }
}
