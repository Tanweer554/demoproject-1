﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee_collection_using_generic_list
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
