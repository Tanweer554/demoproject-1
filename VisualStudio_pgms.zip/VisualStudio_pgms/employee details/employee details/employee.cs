﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace employee_details
{
    class employee
    {
        public string emp_name;
        public double B_Salary, hra, da, tax, gross, net;
        public employee(string name,double salary)
        {
            emp_name = name;
            B_Salary = salary;
        }
        public void calculatenetpay()
        {
            hra = B_Salary *15 / 100;
            da = B_Salary *10 / 100;
            gross = B_Salary + hra + da;
            tax = gross * 8 / 100;
            net = gross - tax;
          }
        public void display()
        {
            Console.WriteLine("Employee Name:{0}",emp_name);
            Console.WriteLine("Basic salary is:{0}",B_Salary);
            Console.WriteLine("-------------------------------------------------");
            Console.WriteLine("HRA is:{0}",hra);
            Console.WriteLine("DA is:{0}", da);
            Console.WriteLine("GROSS is:{0}", gross);
            Console.WriteLine("TAX is:{0}", tax);
            Console.WriteLine("NET is:{0}\n", net);

        }
    }
}
