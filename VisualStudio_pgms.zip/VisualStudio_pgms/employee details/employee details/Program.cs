﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace employee_details
{
    class Program
    {
        static void Main(string[] args)
        {
            employee e1 = new employee("tanweer",18000);
            employee e2 = new employee("manu", 185000);
            e1.calculatenetpay();
            e1.display();
            e2.calculatenetpay();
            e2.display();
            Console.ReadKey();
        }
    }
}
