﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace stringpalindrome
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Enter the string to be checked");
            string str = Console.ReadLine();
            char[] carray = str.ToCharArray();
            Array.Reverse(carray);
            String rstr = new string(carray);
            if (str == rstr)
            {
                Console.WriteLine("{0} is a palindrome", str);
            }
            else
            {
                Console.WriteLine("{0} is not a palindrome", str);
            }
            Console.ReadKey();
        }        
    }

}


