﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace stockdetails
{
    class Program
    {
        static void Main(string[] args)
        {
            stock sc = new stock("delhidaredevils", "eagle", 565000, 455000);
            stock sc1 = new stock("mumbaiindians", "indiangate", 665000, 555000);
            stock sc2 = new stock("kolkattanightriders", "kingfisher", 765000, 255000);
            Console.WriteLine("percentagechange:{0}", sc.GetChangePercentage());
            Console.WriteLine("-------------------------------------------------------\n");
            Console.WriteLine("percentagechange:{0}", sc1.GetChangePercentage());
            Console.WriteLine("-------------------------------------------------------\n");
            Console.WriteLine("percentagechange:{0}", sc2.GetChangePercentage());
            Console.WriteLine("-------------------------------------------------------\n");
            Console.ReadKey();

        }
    }
}
