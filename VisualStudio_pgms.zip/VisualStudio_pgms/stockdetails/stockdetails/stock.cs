﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace stockdetails
{
    class stock
    {
        public string stockname;
        public string stocksymbol;
        public double prev_closing_price, current_closing_price;

        public stock(string stockname,string stocksymbol,double prev_closing_price,double current_closing_price)
        {
            this.stockname = stockname;
            this.stocksymbol = stocksymbol;
            this.prev_closing_price = prev_closing_price;
            this.current_closing_price = current_closing_price;
        }
        public double GetChangePercentage()
        {
          

            Console.WriteLine("Stock name:{0}",stockname);
            Console.WriteLine("Stock symbol:{0}", stocksymbol);
            Console.WriteLine("previous closing price:{0}", prev_closing_price);
            Console.WriteLine("current closing price:{0}", current_closing_price);
            return ((prev_closing_price - current_closing_price) / prev_closing_price) * 100;
        }
    }
}
