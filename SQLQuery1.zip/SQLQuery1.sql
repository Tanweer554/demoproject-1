select * from employee
select * from titles
select * from publishers
select emp_id,fname from employee where (select datepart(year,hire_date))=1991
update employee set lname='drexler' where emp_id='VPA30890F'
update employee set job_id=14 where fname='pedro' and lname='afonso'

insert into employee(emp_id,fname,minit,lname,job_id,job_lvl,pub_id,hire_date,salary) values('AMD14533F','tanweer','M','ahmed',12,34,1389,'1990-04-23',50000)

select SUBSTRING(fname,1,3) as frist_3_chars from employee
select fname from employee where (fname=(select len(fname) from employee))