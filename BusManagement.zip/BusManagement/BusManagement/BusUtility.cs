﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusManagement.Utility
{
    public class BusUtility
    {
        public string GenerateBusID(string Source, string Destination, int ServiceNumber)
        {
            string BID = string.Empty;
            BID += Source[0].ToString().ToUpper() + Destination.ToUpper()+"-"+ServiceNumber.ToString();
            
            return BID;
        }

        public string GenerateBusName(string Source, string Destination)
        {
            string BName = string.Empty;
            BName = Source[0].ToString().ToUpper() + Source[1].ToString().ToLower() + Source[2].ToString().ToUpper()+"-";
            BName += Destination[0].ToString().ToUpper() + Destination[1].ToString().ToLower() + Destination[2].ToString().ToUpper();
            return BName;
        }

        public double FindTicketPrice(int Distance, string ReservationClass)
        {
            double price=0;
            if (ReservationClass == "AC")
                price = Distance * 3.5;
            else if (ReservationClass == "NAC")
                price = Distance * 2;
            return price;
        }
    }
}
