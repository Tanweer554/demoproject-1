﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusManagement
{
    public class BusData
    {
        public List<Bus> BusList { get; set; }

        public BusData()
        {
            BusList = new List<Bus>();
        }

        public string AddBus(Bus objBus)
        {
            if (objBus == null)
                return null;
            else
            {
                Utility.BusUtility bu = new Utility.BusUtility();
                objBus.BusID = bu.GenerateBusID();
                objBus.BusName = bu.GenerateBusName();
                objBus.TicketPrice = bu.FindTicketPrice();
                BusList.Add(objBus);
                return objBus.BusID;

            }
        }
    }
}
